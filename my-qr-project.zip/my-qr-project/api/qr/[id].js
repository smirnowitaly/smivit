
let usedTokens = {};

export default function handler(req, res) {
  const {
    query: { id },
  } = req;

  if (usedTokens[id]) {
    return res.send(`
      <html>
        <body style="background-color: #8B0000; color: white; display: flex; align-items: center; justify-content: center; height: 100vh; font-family: sans-serif;">
          <h1>QR-код уже использован</h1>
        </body>
      </html>
    `);
  }

  usedTokens[id] = true;

  return res.send(`
    <html>
      <body style="background-color: green; color: white; display: flex; align-items: center; justify-content: center; height: 100vh; font-family: sans-serif;">
        <h1>Добро пожаловать</h1>
      </body>
    </html>
  `);
}
